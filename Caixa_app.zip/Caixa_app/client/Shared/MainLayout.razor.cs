﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Radzen;
using Radzen.Blazor;

namespace Caixa.Layouts
{
    public partial class MainLayoutComponent
    {

    }
}
