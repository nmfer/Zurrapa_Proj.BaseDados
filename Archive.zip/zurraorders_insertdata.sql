USE ZurrapaSede;

-- PEDIDOS
INSERT INTO Orders(id_order, id_bar, id_num, table_number, total_price, order_status) VALUES ();
INSERT INTO Orders(id_order, id_bar, id_num, table_number, total_price, order_status) VALUES ();

-- PRODUTOS NO PEDIDO
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();
INSERT INTO Products_order(id_order, id_product, sale_price) VALUES ();