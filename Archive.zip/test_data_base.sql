USE ZurrapaSede;

ALTER TABLE Employee
DROP CONSTRAINT CHK_OPEmpCounter;

/*UPDATE TABLE Bar
SET id_responsible = E.id_num
FROM Branch B, List_Employees E
WHERE E.responsible = 'sim';

UPDATE TABLE Products_in_Warehouse
SET set_to_unit = P.set_to_unit
FROM Products P, Products_in_Warehouse W
WHERE W.id_product = P.id_product;

UPDATE TABLE Emp_Warehouse
SET id_num = E.id_num
FROM Emp_Warehouse W, Employee E
WHERE E.emp_warehouse = 'sim';*/
