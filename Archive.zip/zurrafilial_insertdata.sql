USE ZurrapaSede;

-- FILIAIS
--INSERT INTO Branch(id_branch, designation, email, phone_num, address, id_manager) VALUES (00, '', '', , '', );
INSERT INTO Branch(id_branch, designation, email, phone_num, address, id_manager) VALUES (01, 'ZurrapaSede', 'sede@gmail.com', 275275275, 'n_1 da Avenida Montes Hermínios, Covilhã', 000001);
INSERT INTO Branch(id_branch, designation, email, phone_num, address, id_manager) VALUES (02, 'ZurrapaFilial_1', 'filial_1@gmail.com', 239091888, 'n_2 Rua do Norte, Coimbra', 000002);
INSERT INTO Branch(id_branch, designation, email, phone_num, address, id_manager) VALUES (03, 'ZurrapaFilial_2', 'filial_2@gmail.com', 271876999, 'n_3 Rua Batalha Reis 6301-860, Guarda', 000003);